print("this is the example challenge the server would host as a nc service")
