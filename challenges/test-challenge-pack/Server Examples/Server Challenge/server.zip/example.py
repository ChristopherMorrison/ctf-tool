with open('flag') as fp:
    print(fp.read())
